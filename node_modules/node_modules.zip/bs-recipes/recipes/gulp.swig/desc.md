This example will build HTML files from `./app` with `gulp-swig`
and place them into the `dist` folder. Browsersync then serves from that
folder and reloads after the templates are compiled.