
To see the live-updating and CSS injecting, simply perform changes to either `index.html` or `css/main.css`